import Checkout from './Checkout';
import EarphonesPage from './EarphonesPage';
import HeadphonesPage from './HeadphonesPage';
import HomePage from './HomePage';
import SingleProductPage from './SingleProductPage';
import SpeakersPage from './SpeakersPage';

export {
  Checkout,
  EarphonesPage,
  HeadphonesPage,
  HomePage,
  SingleProductPage,
  SpeakersPage,
};
