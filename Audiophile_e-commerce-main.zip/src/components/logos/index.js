import Facebook from './Facebook';
import Instagram from './Instagram';
import Twitter from './Twitter';

export { Facebook, Instagram, Twitter };
